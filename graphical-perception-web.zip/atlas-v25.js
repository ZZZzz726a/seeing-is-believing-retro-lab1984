/* The established atlas, with a color-only rank legend. */
(() => {
  const host=$('specimens'),CX=380,CY=330,rankShade=['#171717','#49443d','#777066','#a79d8c','#c8baa0','#ffbf00'];
  const short=['共同尺度位置','非对齐位置','长度','方向','角度','面积','体积','曲率','明暗','饱和度'];
  const polar=(r,a)=>[CX+r*Math.cos(a*Math.PI/180),CY+r*Math.sin(a*Math.PI/180)];
  const arc=(r,a,b)=>`M${polar(r,a).join(' ')} A${r} ${r} 0 ${b-a>180?1:0} 1 ${polar(r,b).join(' ')}`;
  const angle=i=>-90+i*36;let ring='';
  [108,156,222,255,265].forEach((r,i)=>ring+=circle(CX,CY,r,'none',`stroke="${i===4?'#777065':'#bcb29f'}" stroke-width="${i===4?1.2:.75}" ${i===1?'stroke-dasharray="1 5"':''}`));
  for(let i=0;i<180;i++){const a=-90+i*2;ring+=line(...polar(i%3===0?258:262,a),...polar(268,a),'#716a5e',i%3===0?1:.55)}
  for(let r=1;r<=6;r++){const ids=specs.map((s,i)=>s[3]===r?i:-1).filter(i=>i>=0),start=angle(ids[0])-15,end=angle(ids.at(-1))+15;ring+=path(arc(244,start,end),'none',rankShade[r-1],12,'stroke-linecap="butt"');}
  const marks=specs.map((s,i)=>{const a=angle(i),[x,y]=polar(180,a),[lx,ly]=polar(287,a),[ix,iy]=polar(108,a),[ox,oy]=polar(222,a),[nx,ny]=polar(126,a);const align=Math.abs(lx-CX)<30?'middle':lx>CX?'start':'end',labelX=lx+(align==='start'?4:align==='end'?-4:0);return `<g class="atlas-spoke" data-spec="${i}" tabindex="0" role="button" aria-pressed="false" aria-label="${s[0]}，理论等级 ${s[3]}"><path class="spoke-connector" d="M${ix} ${iy} L${ox} ${oy}" fill="none" stroke="#999082" stroke-dasharray="2 5" stroke-width="1"/><circle cx="${nx}" cy="${ny}" r="4.5" fill="${rankShade[s[3]-1]}" stroke="#595347" stroke-width=".5"/><circle class="spoke-glow" cx="${x}" cy="${y}" r="42"/><svg class="spoke-glyph" x="${x-51}" y="${y-30}" width="102" height="60" viewBox="0 0 480 250" aria-hidden="true"></svg><circle class="spoke-hit" cx="${x}" cy="${y}" r="47" fill="transparent"/><circle cx="${ox}" cy="${oy}" r="3.3" fill="${ink}"/><text class="spoke-label" x="${labelX}" y="${ly+5}" text-anchor="${align}">${short[i]}</text></g>`}).join('');
  host.classList.add('editorial-orbit');host.innerHTML=`<span id="orbitValue" hidden>60</span><svg class="editorial-atlas" viewBox="0 0 760 660" role="group" aria-label="环形图形编码图谱">${ring}${marks}<circle cx="${CX}" cy="${CY}" r="86" fill="#f5eee3" stroke="#171717" stroke-width="1.25"/><circle cx="${CX}" cy="${CY}" r="78" fill="none" stroke="#b3a895" stroke-width=".6" stroke-dasharray="1 3"/>${tx(CX,CY-36,'SAME VALUE',11,'#706a60','middle','font-weight="700" letter-spacing="2"')}<text id="atlasRatio" x="${CX}" y="${CY+20}" text-anchor="middle" font-size="56" font-weight="900" letter-spacing="-4">60<tspan font-size="23" letter-spacing="0">%</tspan></text>${tx(CX,CY+44,'十种视觉表达',12,'#706a60')}</svg>`;
  const existingSpec=showSpec;
  showSpec=function(){existingSpec();const v=+$('valueSlider').value;$('atlasRatio').innerHTML=`${v}<tspan font-size="23" letter-spacing="0">%</tspan>`;host.querySelectorAll('.atlas-spoke').forEach((g,i)=>{const on=i===selectedSpec;g.classList.toggle('active',on);g.setAttribute('aria-pressed',String(on));g.querySelector('.spoke-glyph').innerHTML=specimen(i,v).replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'').replaceAll('ballb','spoke-ball-'+i)});};
  host.onclick=e=>{const n=e.target.closest('[data-spec]');if(n){selectedSpec=+n.dataset.spec;showSpec()}};
  host.onkeydown=e=>{const n=e.target.closest('[data-spec]');if(n&&['Enter',' '].includes(e.key)){e.preventDefault();selectedSpec=+n.dataset.spec;showSpec();return}if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();e.stopPropagation();selectedSpec=(selectedSpec+(['ArrowUp','ArrowLeft'].includes(e.key)?9:1))%10;showSpec();}};
  document.querySelector('.atlas-overline').innerHTML='<span>编码 / ENCODING ATLAS</span><span>10 类图形 · 6 级感知排序</span>';
  document.querySelector('.atlas-legend').innerHTML='<span class="atlas-key"><i></i>较准确</span><span>环带 = 理论等级 · 非误差数值</span><span class="atlas-key"><i></i>较不准确</span>';
  showSpec();
  // Animate the actual encoded value, not just the SVG container. Live dragging and
  // the existing Play action still render directly on every input frame.
  const renderSpec=showSpec,reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let previous=selectedSpec,frame=0;
  function animateSpec(){
    cancelAnimationFrame(frame);if(reduced.matches||$('atlas').hidden)return;
    const target=+$('valueSlider').value,index=selectedSpec,start=performance.now(),from=5;
    const render=t=>{if(index!==selectedSpec||$('atlas').hidden)return;const p=Math.min(1,(t-start)/850),e=1-Math.pow(1-Math.max(0,p),3),n=from+(target-from)*e;
      $('specChart').innerHTML=specimen(index,n);$('specValue').textContent=Math.round(n);
      if(p<1)frame=requestAnimationFrame(render);else{$('specChart').innerHTML=specimen(index,target);$('specValue').textContent=target;frame=0;}};
    $('specName').animate([{opacity:.3,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:370,easing:'ease-out'});
    frame=requestAnimationFrame(render);
  }
  showSpec=function(){const changed=previous!==selectedSpec;cancelAnimationFrame(frame);frame=0;renderSpec();previous=selectedSpec;if(changed)animateSpec()};
  const priorPage=showPage;showPage=function(i){const was=page;priorPage(i);if(i===4&&was!==4){renderSpec();animateSpec()}else if(i!==4)cancelAnimationFrame(frame)};
  if(page===4)animateSpec();
})();
