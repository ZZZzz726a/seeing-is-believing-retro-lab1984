/* Editorial visualization: ordinal atlas, interactive 3D aggregate network and data threads. */
(() => {
  const reduced=matchMedia('(prefers-reduced-motion: reduce)'), ns='http://www.w3.org/2000/svg';
  const host=$('specimens'), CX=380,CY=330,rankShade=['#171717','#49443d','#777066','#a79d8c','#c8baa0','#ffbf00'];
  const short=['共同尺度位置','非对齐位置','长度','方向','角度','面积','体积','曲率','明暗','饱和度'];
  const polar=(r,a)=>[CX+r*Math.cos(a*Math.PI/180),CY+r*Math.sin(a*Math.PI/180)];
  const arc=(r,a,b)=>`M${polar(r,a).join(' ')} A${r} ${r} 0 ${b-a>180?1:0} 1 ${polar(r,b).join(' ')}`;
  const angle=i=>-90+i*36;
  let ring='';
  [108,156,222,255,265].forEach((r,i)=>ring+=circle(CX,CY,r,'none',`stroke="${i===4?'#777065':'#bcb29f'}" stroke-width="${i===4?1.2:.75}" ${i===1?'stroke-dasharray="1 5"':''}`));
  for(let i=0;i<180;i++){const a=-90+i*2;ring+=line(...polar(i%3===0?258:262,a),...polar(268,a),'#716a5e',i%3===0?1:.55)}
  for(let r=1;r<=6;r++){
    const ids=specs.map((s,i)=>s[3]===r?i:-1).filter(i=>i>=0),start=angle(ids[0])-15,end=angle(ids.at(-1))+15;
    ring+=path(arc(244,start,end),'none',rankShade[r-1],12,'stroke-linecap="butt"');
    const [x,y]=polar(244,(start+end)/2);ring+=tx(x,y+3.5,`R${r}`,10,r<4?paper:ink,'middle','font-weight="900"');
  }
  const marks=specs.map((s,i)=>{const a=angle(i),[x,y]=polar(180,a),[lx,ly]=polar(287,a),[ix,iy]=polar(108,a),[ox,oy]=polar(222,a),[nx,ny]=polar(126,a);const align=Math.abs(lx-CX)<30?'middle':lx>CX?'start':'end',labelX=lx+(align==='start'?4:align==='end'?-4:0);return `<g class="atlas-spoke" data-spec="${i}" tabindex="0" role="button" aria-pressed="false" aria-label="${s[0]}，理论等级 ${s[3]}"><path class="spoke-connector" d="M${ix} ${iy} L${ox} ${oy}" fill="none" stroke="#999082" stroke-dasharray="2 5" stroke-width="1"/><circle cx="${nx}" cy="${ny}" r="4.5" fill="${rankShade[s[3]-1]}" stroke="#595347" stroke-width=".5"/><circle class="spoke-glow" cx="${x}" cy="${y}" r="42"/><svg class="spoke-glyph" x="${x-51}" y="${y-30}" width="102" height="60" viewBox="0 0 480 250" aria-hidden="true"></svg><circle class="spoke-hit" cx="${x}" cy="${y}" r="47" fill="transparent"/><circle cx="${ox}" cy="${oy}" r="3.3" fill="${ink}"/><text class="spoke-label" x="${labelX}" y="${ly+5}" text-anchor="${align}">${short[i]}</text></g>`}).join('');
  host.classList.add('editorial-orbit');host.innerHTML=`<span id="orbitValue" hidden>60</span><svg class="editorial-atlas" viewBox="0 0 760 660" role="group" aria-label="环形图形编码图谱">${ring}${marks}<circle cx="${CX}" cy="${CY}" r="86" fill="#f5eee3" stroke="#171717" stroke-width="1.25"/><circle cx="${CX}" cy="${CY}" r="78" fill="none" stroke="#b3a895" stroke-width=".6" stroke-dasharray="1 3"/>${tx(CX,CY-36,'SAME VALUE',11,'#706a60','middle','font-weight="700" letter-spacing="2"')}<text id="atlasRatio" x="${CX}" y="${CY+20}" text-anchor="middle" font-size="56" font-weight="900" letter-spacing="-4">60<tspan font-size="23" letter-spacing="0">%</tspan></text>${tx(CX,CY+44,'十种视觉表达',12,'#706a60')}</svg>`;
  const existingSpec=showSpec;
  showSpec=function(){existingSpec();const v=+$('valueSlider').value;$('atlasRatio').innerHTML=`${v}<tspan font-size="23" letter-spacing="0">%</tspan>`;host.querySelectorAll('.atlas-spoke').forEach((g,i)=>{const on=i===selectedSpec;g.classList.toggle('active',on);g.setAttribute('aria-pressed',String(on));g.querySelector('.spoke-glyph').innerHTML=specimen(i,v).replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'').replaceAll('ballb','spoke-ball-'+i)});};
  host.onclick=e=>{const n=e.target.closest('[data-spec]');if(n){selectedSpec=+n.dataset.spec;showSpec()}};
  host.onkeydown=e=>{const n=e.target.closest('[data-spec]');if(n&&['Enter',' '].includes(e.key)){e.preventDefault();selectedSpec=+n.dataset.spec;showSpec();return}if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();e.stopPropagation();selectedSpec=(selectedSpec+(['ArrowUp','ArrowLeft'].includes(e.key)?9:1))%10;showSpec();}};
  document.querySelector('.atlas-overline').innerHTML='<span>编码 / ENCODING ATLAS</span><span>10 类图形 · 6 级感知排序</span>';
  document.querySelector('.atlas-legend').innerHTML='<span>R1 较准确</span><span>环带 = 理论等级 · 非误差数值</span><span>R6 较不准确</span>';
  showSpec();

  // Two experimental groups and 663 equally-defined points. Their spatial layout is schematic, not a measured quantity.
  const oldResearch=renderResearch;let graphStop=null;
  function graphOverview(){
    if(graphStop)graphStop();const container=$('researchContent');
    $('researchInsight').innerHTML='<b>6,630 次判断</b><span>从实验规模到图形感知证据 · 每个外围节点 = 10 次判断</span>';
    document.querySelectorAll('[data-research]').forEach(b=>b.classList.toggle('active',+b.dataset.research===3));
    container.innerHTML=`<div class="network-study"><div class="network-stage"><div class="network-meta"><span>EXPERIMENT NETWORK / 1984</span><span>3D · AGGREGATE DATA</span></div><canvas id="studyNetwork" tabindex="0" aria-label="可旋转的三维实验汇总图，实验A 255点，实验B 408点；方向键旋转，正负键缩放"></canvas><div class="network-toolbar"><span>拖动旋转 · 滚轮缩放</span><div><button id="netMinus" aria-label="缩小">−</button><button id="netPlus" aria-label="放大">+</button><button id="netReset">复位</button></div></div></div><aside class="network-side"><span class="mono">OBSERVATIONS / 观测</span><div class="network-total">6,630</div><p>两组实验的有效判断</p><div class="network-legend"><button data-network="0" aria-pressed="false"><i></i><span><b>实验 A</b>位置 / 长度</span><strong>2,550</strong></button><button data-network="1" aria-pressed="false"><i></i><span><b>实验 B</b>位置 / 角度</span><strong>4,080</strong></button></div><p id="netDetail">点击实验节点或右侧分类，聚焦其中一组。</p><button class="primary" id="netResults">查看实验结果</button></aside></div><p class="fine">空间结构为实验归属示意；663 个外围节点各代表 10 次判断，不对应个体、误差或时间，空间距离不代表数值。</p>`;
    const canvas=$('studyNetwork'),ctx=canvas.getContext('2d'),clusters=[255,408],nodes=[];let select=null,yaw=.17,pitch=-.08,zoom=1,drag=null,raf=0,dead=false,prev=performance.now(),screenNodes=[];
    const hubs=[[-.57,0,0],[.57,0,0]],colors=['#efeadc','#ffbf00'],phi=Math.PI*(3-Math.sqrt(5));
    clusters.forEach((n,k)=>{for(let i=0;i<n;i++){const y=1-2*(i+.5)/n,r=Math.sqrt(1-y*y),theta=phi*i+k*.83;const shell=.36+.31*Math.sqrt(((i*47)%n+.5)/n);nodes.push({k,x:hubs[k][0]+Math.cos(theta)*r*shell,y:y*shell,z:Math.sin(theta)*r*shell});}});
    const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
    function selectGroup(k){select=select===k?null:k;container.querySelectorAll('[data-network]').forEach(b=>{const on=+b.dataset.network===select;b.classList.toggle('selected',on);b.setAttribute('aria-pressed',String(on));});$('netDetail').textContent=select===null?'点击实验节点或右侧分类，聚焦其中一组。':select===0?'实验 A · 255 个汇总节点，共 2,550 次判断，51 位有效受试者。':'实验 B · 408 个汇总节点，共 4,080 次判断，51 位有效受试者。';}
    container.querySelectorAll('[data-network]').forEach(b=>b.onclick=()=>selectGroup(+b.dataset.network));$('netResults').onclick=()=>{researchTab=0;renderResearch()};
    function project(x,y,z,w,h){const ca=Math.cos(yaw),sa=Math.sin(yaw),cb=Math.cos(pitch),sb=Math.sin(pitch),xx=x*ca+z*sa,zz=z*ca-x*sa,yy=y*cb-zz*sb,depth=y*sb+zz*cb;const scale=Math.min(w*.39,h*.73)*zoom,focus=3.3/(3.3-depth);return{x:w/2+xx*scale*focus,y:h/2+yy*scale*focus,z:depth,scale:focus};}
    function draw(now){if(dead||!canvas.isConnected){graphStop?.();return}if(page!==5||researchTab!==3){prev=now;raf=requestAnimationFrame(draw);return}const rect=canvas.getBoundingClientRect(),w=rect.width,h=rect.height;if(w<2||h<2){raf=requestAnimationFrame(draw);return}const dpr=Math.min(2,devicePixelRatio||1);if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);if(!drag&&!reduced.matches)yaw+=Math.min(50,now-prev)*.00016;prev=now;
      // Projection guide and reference reticle. These are purely spatial guides.
      ctx.strokeStyle='#ffffff12';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(w/2,12);ctx.lineTo(w/2,h-12);ctx.moveTo(12,h/2);ctx.lineTo(w-12,h/2);ctx.stroke();
      const pH=hubs.map(p=>project(...p,w,h)),root=project(0,0,0,w,h);const mapped=nodes.map(n=>({...project(n.x,n.y,n.z,w,h),k:n.k})).sort((a,b)=>a.z-b.z);screenNodes=mapped;
      for(let k=0;k<2;k++){ctx.strokeStyle=select!==null&&select!==k?'#ffffff10':k?'#ffbf0070':'#eee8db70';ctx.lineWidth=1.3;ctx.beginPath();ctx.moveTo(root.x,root.y);ctx.lineTo(pH[k].x,pH[k].y);ctx.stroke();}
      for(const n of mapped){const c=pH[n.k],dim=select!==null&&select!==n.k,alpha=dim?.055:.085+clamp((n.z+1)/2,0,1)*.22;ctx.globalAlpha=alpha;ctx.strokeStyle=colors[n.k];ctx.lineWidth=.52;ctx.beginPath();ctx.moveTo(c.x,c.y);ctx.lineTo(n.x,n.y);ctx.stroke();}
      for(const n of mapped){const dim=select!==null&&select!==n.k;ctx.globalAlpha=dim?.13:.48+clamp((n.z+1)/2,0,1)*.5;ctx.fillStyle=colors[n.k];ctx.beginPath();ctx.arc(n.x,n.y,clamp(1.65*n.scale*zoom,.9,4.1),0,Math.PI*2);ctx.fill();}
      ctx.globalAlpha=1;ctx.strokeStyle='#f0ebe0';ctx.lineWidth=1;ctx.beginPath();ctx.arc(root.x,root.y,8,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#f0ebe0';ctx.beginPath();ctx.arc(root.x,root.y,3,0,Math.PI*2);ctx.fill();
      pH.forEach((p,k)=>{ctx.globalAlpha=select!==null&&select!==k?.35:1;ctx.fillStyle='#171717';ctx.strokeStyle=colors[k];ctx.lineWidth=2;ctx.beginPath();ctx.arc(p.x,p.y,16,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle=colors[k];ctx.font='bold 16px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(k?'B':'A',p.x,p.y);ctx.font='bold 12px monospace';ctx.strokeStyle='#171717';ctx.lineWidth=4;ctx.strokeText(k?'4,080':'2,550',p.x,p.y+29);ctx.fillText(k?'4,080':'2,550',p.x,p.y+29);});ctx.globalAlpha=1;raf=requestAnimationFrame(draw);
    }
    canvas.onpointerdown=e=>{drag={x:e.clientX,y:e.clientY,ox:e.clientX,oy:e.clientY};canvas.setPointerCapture(e.pointerId);canvas.classList.add('dragging')};canvas.onpointermove=e=>{if(!drag)return;yaw+=(e.clientX-drag.x)*.008;pitch=clamp(pitch+(e.clientY-drag.y)*.007,-1.45,1.45);drag.x=e.clientX;drag.y=e.clientY;};canvas.onpointerup=e=>{if(drag&&Math.hypot(e.clientX-drag.ox,e.clientY-drag.oy)<5){const box=canvas.getBoundingClientRect(),x=e.clientX-box.left,y=e.clientY-box.top;let near=null,dist=32;for(const n of screenNodes){const q=Math.hypot(x-n.x,y-n.y);if(q<dist){dist=q;near=n.k}}if(near!==null)selectGroup(near);}drag=null;canvas.classList.remove('dragging')};canvas.onpointercancel=()=>{drag=null;canvas.classList.remove('dragging')};
    canvas.addEventListener('wheel',e=>{e.preventDefault();e.stopPropagation();zoom=clamp(zoom*Math.exp(-e.deltaY*.001),.62,2.5)},{passive:false});canvas.onkeydown=e=>{const keys={ArrowLeft:[-.15,0],ArrowRight:[.15,0],ArrowUp:[0,-.12],ArrowDown:[0,.12]};if(keys[e.key]){e.stopPropagation();e.preventDefault();yaw+=keys[e.key][0];pitch=clamp(pitch+keys[e.key][1],-1.45,1.45)}else if(['+','-','='].includes(e.key)){e.preventDefault();zoom=clamp(zoom*(e.key==='-'?.86:1.15),.62,2.5)}};
    $('netPlus').onclick=()=>zoom=clamp(zoom*1.2,.62,2.5);$('netMinus').onclick=()=>zoom=clamp(zoom/1.2,.62,2.5);$('netReset').onclick=()=>{yaw=.17;pitch=-.08;zoom=1;if(select!==null)selectGroup(select)};
    graphStop=()=>{dead=true;cancelAnimationFrame(raf);graphStop=null};raf=requestAnimationFrame(draw);
  }
  renderResearch=function(){if(graphStop)graphStop();if(researchTab===3)graphOverview();else oldResearch()};if(page===5&&researchTab===3)renderResearch();

  // Correspondence threads: constant-width lines carry identity, never imply flow volume.
  let threadGeneration=0;
  function threads(){const wrap=$('reconBefore').closest('.recon-body');wrap.querySelector('.thread-layer')?.remove();if(!reformed||page!==6)return;
    const a=$('reconBefore').querySelector('svg'),b=$('reconAfter').querySelector('svg');if(!a||!b)return;const rect=wrap.getBoundingClientRect(),A=a.getScreenCTM(),B=b.getScreenCTM();if(!A||!B||!rect.width||!rect.height)return;
    const layer=document.createElementNS(ns,'svg');layer.classList.add('thread-layer');layer.setAttribute('viewBox',`0 0 ${rect.width} ${rect.height}`);layer.setAttribute('aria-hidden','true');const convert=(p,M)=>{const q=new DOMPoint(...p).matrixTransform(M);return [q.x-rect.left,q.y-rect.top]};const d=recon[rc].data,pts=[...b.querySelectorAll('circle')],items=[];
    const add=(from,to,c,label)=>items.push({from:convert(from,A),to:convert(to,B),c,label});const point=t=>[+t.getAttribute('cx'),+t.getAttribute('cy')];
    if(rc===0){let begin=0;d.forEach((v,i)=>{const a=(begin+v*1.8-90)*Math.PI/180;add([240+Math.cos(a)*80,123+Math.sin(a)*80],point(pts[i]),shades[i],String.fromCharCode(65+i));begin+=v*3.6})}
    if(rc===1){d.forEach((g,i)=>{let y=220;g.forEach((v,j)=>{let h=v*3.2;y-=h;add([128+i*118,y+h/2],point(pts[i*4+j]),shades[j],`${String.fromCharCode(65+i)}${j+1}`)})});}
    if(rc===2){d[0].forEach((v,i)=>add([54+i*60,220-(v+d[1][i])/2*4.8],point(pts[i]),'#b58a09',String(i+1)))}
    if(rc===3){const bars=[...b.querySelectorAll('rect')].filter(r=>r.getAttribute('fill')!=='none');d.forEach((v,i)=>{const r=bars[i];add([87+i%4*107,70+Math.floor(i/4)*110],[+r.getAttribute('x')+24,+r.getAttribute('y')],`rgb(${245-v*2},${245-v*2},${245-v*2})`,String.fromCharCode(65+i))});}
    items.forEach(({from,to,c,label},i)=>{const [x,y]=from,[xx,yy]=to,mid=(x+xx)/2,gap=Math.abs(xx-x)*.43;const p=`M${x} ${y} C${x+gap} ${y} ${xx-gap} ${yy} ${xx} ${yy}`;const g=document.createElementNS(ns,'g');g.classList.add('thread');g.innerHTML=`<path class="thread-visible" d="${p}" stroke="${c}" fill="none"/><path class="thread-hit" d="${p}" fill="none" stroke="transparent" stroke-width="12"/><title>${label} · 同一数据项</title>`;g.style.setProperty('--i',i);g.onpointerenter=()=>layer.classList.add('highlighting');g.onpointerleave=()=>layer.classList.remove('highlighting');layer.append(g)});wrap.append(layer);
    const note=$('reconData');if(!note.querySelector('.thread-note'))note.insertAdjacentHTML('beforeend','<span class="thread-note">流线 = 同一数据项 · 非流量</span>');
  }
  const priorRecon=renderRecon;renderRecon=function(){threadGeneration++;document.querySelector('.thread-layer')?.remove();priorRecon();if(reformed){const id=threadGeneration;setTimeout(()=>{if(id===threadGeneration)threads()},reduced.matches?0:1100)}};
  const previousToggle=$('reconToggle').onclick;$('reconToggle').onclick=function(){previousToggle();if(reformed){const id=++threadGeneration;setTimeout(()=>{if(id===threadGeneration)threads()},reduced.matches?0:1550)}};
  const previousPage=showPage;showPage=function(i){threadGeneration++;document.querySelector('.thread-layer')?.remove();previousPage(i);if(i===6&&reformed)requestAnimationFrame(threads);if(i!==5&&graphStop)graphStop();};
  let resizeTimer;addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(page===6&&reformed)threads()},120)});
})();
