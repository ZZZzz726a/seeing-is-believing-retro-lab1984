/* Data-bearing visual layers. Retains all eight chapters and experimental inputs. */
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const rankColors = ['#171717','#55514b','#a79d8b','#bbad91','#d5c4a0','#ffbf00'];
  const atlas = $('specimens');
  const shortNames = ['共同尺度位置','非对齐位置','长度','方向','角度','面积','体积','曲率','明暗','饱和度'];
  atlas.parentElement.classList.add('radial-atlas');
  atlas.parentElement.innerHTML = `<div class="atlas-overline"><span>感知图谱 / PERCEPTUAL ATLAS</span><span>10 种编码 · 6 个等级</span></div><div id="specimens" class="atlas-orbit" tabindex="0" aria-label="十种图形编码，点击或用方向键探索"></div><div class="atlas-legend"><span><b>01</b> 较准确</span><span>六级理论排序 · 同级并列</span><span>较不准确 <b>06</b></span></div>`;
  const orbit = $('specimens');
  const xy = i => { const a = (i*36-90)*Math.PI/180; return [50+38*Math.cos(a),50+36*Math.sin(a)]; };
  const polar = (r,a) => [500+r*Math.cos(a*Math.PI/180),500+r*Math.sin(a*Math.PI/180)];
  function arc(r,a,b){const p=polar(r,a),q=polar(r,b);return `M${p.join(' ')} A${r} ${r} 0 ${b-a>180?1:0} 1 ${q.join(' ')}`;}
  let rings = `<circle cx="500" cy="500" r="352" fill="none" stroke="#a49b8a" stroke-width="1" stroke-dasharray="2 8"/><circle cx="500" cy="500" r="240" fill="none" stroke="#bcb1a0" stroke-width="1.3"/><circle cx="500" cy="500" r="170" fill="none" stroke="#bcb1a0" stroke-width="1" stroke-dasharray="4 7"/>`;
  for(let i=0;i<60;i++){const a=i*6-90,p=polar(i%5===0?251:258,a),q=polar(269,a);rings+=line(...p,...q,ink,i%5===0?1.8:.7);}
  for(let r=1;r<=6;r++){const ids=specs.map((s,i)=>s[3]===r?i:-1).filter(i=>i>=0),a=ids[0]*36-90-14,b=ids.at(-1)*36-90+14; rings+=path(arc(280,a,b),'none',rankColors[r-1],13,'stroke-linecap="round"');}
  orbit.innerHTML=`<svg class="orbit-lines" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-hidden="true">${rings}${specs.map((s,i)=>{const a=i*36-90;return line(...polar(295,a),...polar(365,a),'#9c9486',1.3,'stroke-dasharray="3 6"')}).join('')}</svg><div class="orbit-center"><span>同一比例 / SAME VALUE</span><strong id="orbitValue">60<small>%</small></strong><span>10 种视觉表达</span></div>${specs.map((s,i)=>{const [x,y]=xy(i);return `<button class="orbit-node" data-spec="${i}" aria-pressed="false" aria-label="${s[0]}，理论等级${s[3]}" style="--x:${x}%;--y:${y}%"><span class="orbit-rank">${String(s[3]).padStart(2,'0')}</span><span class="orbit-glyph"></span><span class="orbit-label">${shortNames[i]}</span></button>`}).join('')}`;
  // Reattach the original selection and keyboard affordances after moving the index.
  const select = i => {selectedSpec=i;showSpec()};
  orbit.onclick=e=>{const b=e.target.closest('[data-spec]');if(b)select(+b.dataset.spec)};
  orbit.onkeydown=e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();e.stopPropagation();select(Math.max(0,Math.min(9,selectedSpec+(['ArrowUp','ArrowLeft'].includes(e.key)?-1:1))))}};
  let last=0;orbit.onwheel=e=>{e.preventDefault();e.stopPropagation();if(performance.now()-last<180)return;last=performance.now();select(Math.max(0,Math.min(9,selectedSpec+Math.sign(e.deltaY))))};
  const originalSpec=showSpec;
  showSpec=function(){originalSpec();const v=+$('valueSlider').value;$('orbitValue').innerHTML=`${v}<small>%</small>`;orbit.querySelectorAll('.orbit-node').forEach((b,i)=>{b.querySelector('.orbit-glyph').innerHTML=specimen(i,v).replaceAll('ballb','orbit-ball-'+i);});};
  showSpec();

  // An additional overview uses a deliberately aggregated unit (10 judgments), not reconstructed subjects.
  $('researchTabs').insertAdjacentHTML('afterbegin','<button data-research="3">实验全景</button>');
  let selectedExperiment=null;
  function drawScaleOverview(){
    const info=$('researchInsight'),host=$('researchContent');
    info.innerHTML='<b>6,630 次图形判断</b><span>两组实验 · 51 位有效受试者 / 组 · 每点代表 10 次判断</span>';
    document.querySelectorAll('[data-research]').forEach(b=>b.classList.toggle('active',+b.dataset.research===3));
    const counts=[255,408],rs=[5,8];
    const cards=counts.map((n,k)=>{
      const cx=230,cy=195;let body='';
      for(let ring=0;ring<rs[k];ring++){
        const rad=41+ring*18;body+=circle(cx,cy,rad,'none','stroke="#c7bcaa" stroke-width=".8" stroke-dasharray="2 3"');
        for(let i=0;i<51;i++){const a=(i/51*360-90)*Math.PI/180;body+=`<circle class="sample-mark" cx="${cx+Math.cos(a)*rad}" cy="${cy+Math.sin(a)*rad}" r="2.3" fill="${k?red:ink}" style="--delay:${Math.min(500,ring*65+i*2)}ms"/>`;}
      }
      body+=tx(cx,cy-2,k?'B':'A',32,ink,'middle','font-weight="900"')+tx(cx,cy+19,'实验',12,ink);
      return `<button class="sample-card" data-experiment="${k}" aria-pressed="${selectedExperiment===k}" aria-label="实验${k?'B':'A'}，${n*10}次判断，查看实验详情"><div class="sample-title"><span>EXPERIMENT 0${k+1}</span><b>${k?'位置 / 角度':'位置 / 长度'}</b></div>${svg(body,460,390,`${n}个点，每点10次判断`)}<div class="sample-reading"><strong>${(n*10).toLocaleString('en-US')}</strong><span>次判断<br>51 位有效受试者</span></div></button>`;
    }).join('');
    host.innerHTML=`<div class="sample-overview">${cards}<aside class="sample-key"><span class="mono">RESEARCH SCALE</span><strong>6,630</strong><span>总判断次数</span><div class="sample-share"><i style="width:${2550/6630*100}%"></i><i style="width:${4080/6630*100}%"></i></div><div class="sample-labels"><span>● A　2,550</span><span><i></i> B　4,080</span></div><hr><p id="sampleDetail">选择任一实验，查看判断规模及任务构成。</p><button id="sampleCompare" class="primary">比较实验结果</button></aside></div><p class="fine">点阵仅表示原文汇总判断次数，每个点为 10 次判断；不表示个体、误差或时间顺序。</p>`;
    function update(){host.querySelectorAll('[data-experiment]').forEach(b=>{const active=+b.dataset.experiment===selectedExperiment;b.classList.toggle('chosen',active);b.setAttribute('aria-pressed',String(active))});$('sampleDetail').textContent=selectedExperiment===null?'选择任一实验，查看判断规模及任务构成。':selectedExperiment===0?'实验 A：2,550 次判断，比较位置与长度编码的判断准确性。':'实验 B：4,080 次判断，比较柱形图位置与饼图角度的判断准确性。';}
    host.querySelectorAll('[data-experiment]').forEach(b=>b.onclick=()=>{const i=+b.dataset.experiment;selectedExperiment=selectedExperiment===i?null:i;update()});$('sampleCompare').onclick=()=>{researchTab=0;renderResearch()};update();
  }
  const originalResearch=renderResearch;
  renderResearch=function(){if(researchTab===3)drawScaleOverview();else originalResearch()};
  researchTab=3;if(page===5)renderResearch();

  // Group the user's actual fourteen observations by task, retaining access to every trial.
  const originalReport=paintReport;
  paintReport=function(){originalReport();if(answers.length!==14||!$('reportPlot'))return;
    const X=v=>311+v*1.78,Y=i=>37+i*43;let s='';
    [-100,-50,0,50,100].forEach(v=>{s+=line(X(v),18,X(v),332,v===0?ink:'#bdb4a4',v===0?1.9:.8,v===0?'':'stroke-dasharray="3 5"')+tx(X(v),352,sign(v),11)});
    s+=tx(X(-65),12,'低估',11,'#7d776c')+tx(X(65),12,'高估',11,'#8d6900')+tx(311,374,'估计值 − 真实值（百分点）',12);
    taskNames.forEach((n,t)=>{const y=Y(t),ids=answers.map((a,i)=>a.type===t?i:-1).filter(i=>i>=0);s+=tx(117,y+4,n,11,ink,'end')+line(129,y+18,495,y+18,'#c6bdad',.5);ids.forEach((i,j)=>{const a=answers[i],yy=y+(j?7:-7),c=a.error<0?'#8c8981':red,active=obs===i;s+=`<g class="obs-mark" tabindex="0" role="button" data-obs="${i}" aria-label="观测${i+1}，${n}，误差${sign(a.error)}百分点" opacity="${filter!==null&&filter!==t?.2:1}">${line(X(0),yy,X(a.error),yy,c,active?2.5:1.2)}${circle(X(a.error),yy,active?6.5:4.6,c,`stroke="${active?ink:paper}" stroke-width="${active?1.7:1}"`)}${circle(X(a.error),yy,12,'transparent')}</g>`;});});
    $('reportPlot').innerHTML=svg(s,510,385,'七类任务的十四次观测误差，按任务分组');
    $('reportPlot').querySelectorAll('[data-obs]').forEach(g=>{const fn=()=>{obs=+g.dataset.obs;paintReport()};g.onclick=fn;g.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();fn()}}});
    const note=$('reportPlot').nextElementSibling;if(note)note.textContent='每类两次观测 · 左侧低估，右侧高估 · 点击任一点查看详情';
  };
  if(page===3&&answers.length===14)paintReport();

  // Keep category identity while moving actual encoded marks between the two coordinate spaces.
  const NS='http://www.w3.org/2000/svg';let morphGeneration=0;
  const segment=(a,b,n=24)=>Array.from({length:n},(_,i)=>[a[0]+(b[0]-a[0])*i/(n-1),a[1]+(b[1]-a[1])*i/(n-1)]);
  const box=(x,y,w,h)=>[[x,y],[x+w,y],[x+w,y+h],[x,y+h]].flatMap((v,i,all)=>segment(v,all[(i+1)%4],6));
  const disk=(x,y,r)=>Array.from({length:24},(_,i)=>[x+Math.cos(i*2*Math.PI/24)*r,y+Math.sin(i*2*Math.PI/24)*r]);
  const sector=(cx,cy,r,start,sweep)=>[[cx,cy],...Array.from({length:22},(_,i)=>{const a=(start+sweep*i/21-90)*Math.PI/180;return [cx+r*Math.cos(a),cy+r*Math.sin(a)]}),[cx,cy]];
  const originalReconstruction=renderRecon;
  function identity(){if(!reformed)return;const g=$('reconAfter').querySelector('svg');if(!g)return;if(rc===0)[...g.querySelectorAll('circle')].forEach((c,i)=>{c.setAttribute('fill',shades[i]);c.setAttribute('stroke',ink);c.setAttribute('stroke-width','.8')});if(rc===1)[...g.querySelectorAll('circle')].forEach((c,i)=>{if(i%4!==3){c.setAttribute('fill',shades[i%4]);c.setAttribute('stroke',ink);c.setAttribute('stroke-width','.7')}});}
  renderRecon=function(){morphGeneration++;document.querySelector('.morph-layer')?.remove();originalReconstruction();identity()};
  function transformMarks(){
    const host=$('reconBefore').closest('.recon-body'),a=$('reconBefore').querySelector('svg'),b=$('reconAfter').querySelector('svg');if(!a||!b||reduced.matches)return;
    b.getAnimations({subtree:true}).forEach(x=>x.cancel());
    const r=host.getBoundingClientRect(),W=r.width,H=r.height;if(!W||!H)return;
    const A=a.getScreenCTM(),B=b.getScreenCTM();if(!A||!B)return;
    const map=(p,m)=>{const t=new DOMPoint(...p).matrixTransform(m);return[t.x-r.left,t.y-r.top]};
    const overlay=document.createElementNS(NS,'svg');overlay.classList.add('morph-layer');overlay.setAttribute('viewBox',`0 0 ${W} ${H}`);overlay.setAttribute('aria-hidden','true');host.append(overlay);
    const d=recon[rc].data,marks=[];
    const add=(from,to,color,target,label)=>{const p=document.createElementNS(NS,'path');p.setAttribute('fill',color);p.setAttribute('stroke',ink);p.setAttribute('stroke-width','.6');p.setAttribute('stroke-linejoin','round');overlay.append(p);if(target)target.style.opacity='0';const text=document.createElementNS(NS,'text');text.setAttribute('text-anchor','middle');text.setAttribute('font-size','11');text.setAttribute('font-weight','800');text.setAttribute('fill',color===ink?paper:ink);text.textContent=label;overlay.append(text);marks.push({p,text,from:from.map(q=>map(q,A)),to:to.map(q=>map(q,B)),target});};
    const points=[...b.querySelectorAll('circle')];
    if(rc===0){let ang=0;d.forEach((v,i)=>{const t=points[i];add(sector(240,123,99,ang,v*3.6),disk(+t.getAttribute('cx'),+t.getAttribute('cy'),6),shades[i],t,String.fromCharCode(65+i));ang+=v*3.6;});}
    if(rc===1){d.forEach((g,i)=>{let y=220;g.forEach((v,j)=>{let h=v*3.2;y-=h;const t=points[i*4+j];add(box(96+i*118,y,65,h),disk(+t.getAttribute('cx'),+t.getAttribute('cy'),4),shades[j],t,String(j+1));});});}
    if(rc===2){d[0].forEach((v,i)=>{const x=54+i*60,y1=220-v*4.8,y2=220-d[1][i]*4.8,t=points[i];add(box(x-1.5,y2,3,y1-y2),disk(+t.getAttribute('cx'),+t.getAttribute('cy'),4),red,t,'');});}
    if(rc===3){const dest=[...b.querySelectorAll('rect')].filter(x=>x.getAttribute('fill')!=='none');d.forEach((v,i)=>{const x=43+i%4*107,y=25+Math.floor(i/4)*110,t=dest[i],shade=Math.round(245-v*2);add(box(x,y,88,90),box(x+20,y+85-v*.85,48,v*.85),`rgb(${shade},${shade},${shade})`,t,'');});}
    const ticket=++morphGeneration,started=performance.now();
    function frame(now){if(ticket!==morphGeneration||!overlay.isConnected){overlay.remove();return;}let done=true;marks.forEach((m,i)=>{const u=Math.max(0,Math.min(1,(now-started-i*45)/950)),e=u*u*(3-2*u);if(u<1)done=false;const pts=m.from.map((p,j)=>[p[0]+(m.to[j][0]-p[0])*e,p[1]+(m.to[j][1]-p[1])*e]);m.p.setAttribute('d',`M${pts.map(q=>q.join(' ')).join('L')}Z`);const center=pts.reduce((s,p)=>[s[0]+p[0]/pts.length,s[1]+p[1]/pts.length],[0,0]);m.text.setAttribute('x',center[0]);m.text.setAttribute('y',center[1]+3);m.text.setAttribute('opacity',String(1-u));m.p.setAttribute('opacity',String(u>.85?(1-u)/.15:1));if(m.target)m.target.style.opacity=String(u>.8?(u-.8)/.2:0);});if(done){marks.forEach(m=>{if(m.target)m.target.style.opacity=''});overlay.remove();}else requestAnimationFrame(frame);}
    requestAnimationFrame(frame);
  }
  $('reconToggle').onclick=()=>{reformed=!reformed;renderRecon();if(reformed)transformMarks()};
  const previousPage=showPage;showPage=function(i){morphGeneration++;document.querySelector('.morph-layer')?.remove();previousPage(i);if(i===6)identity()};
  identity();
})();
