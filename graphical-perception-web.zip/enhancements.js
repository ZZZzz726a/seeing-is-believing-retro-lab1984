/* Motion is a visual introduction to real, unchanged chart coordinates. */
(() => {
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const ease='cubic-bezier(.22,.76,.22,1)';
  let trialGeneration=0;
  const motion=(el,frames,duration=500,delay=0)=>{
    if(!el||reduced.matches||!el.animate)return;
    return el.animate(frames,{duration,delay,easing:ease,fill:'backwards'});
  };
  const fade=(el,delay=0,duration=380)=>motion(el,[{opacity:0},{opacity:1}],duration,delay);
  const dot=(el,delay=0)=>motion(el,[{opacity:0,transform:'scale(.15)'},{opacity:1,transform:'scale(1)'}],460,delay);
  const draw=(el,delay=0,duration=680)=>{
    if(!el||reduced.matches||!el.getTotalLength)return;
    const length=el.getTotalLength();if(length<1)return;
    motion(el,[{strokeDasharray:`${length} ${length}`,strokeDashoffset:length},{strokeDasharray:`${length} ${length}`,strokeDashoffset:0}],duration,delay);
  };
  const reveal=(el,from,delay=0,duration=620)=>motion(el,[{clipPath:from,opacity:.45},{clipPath:'inset(0 0 0 0)',opacity:1}],duration,delay);

  // Animate real SVG marks around their data baseline, never the whole chart.
  const svgNS='http://www.w3.org/2000/svg';
  function wrapMarks(svg,marks){
    if(!marks.length)return null;
    const group=document.createElementNS(svgNS,'g');
    svg.insertBefore(group,marks[0]);marks.forEach(m=>group.append(m));return group;
  }
  function grow(el,origin,delay=0,duration=730,axis='Y'){
    if(!el)return;
    el.style.transformBox='view-box';el.style.transformOrigin=origin;
    motion(el,[{transform:`scale${axis}(.015)`,opacity:.7},{transform:`scale${axis}(1)`,opacity:1}],duration,delay);
  }
  function growColumns(svg,base,duration=730,stagger=0){
    const columns=new Map(),children=[...svg.children];
    children.filter(e=>e.tagName.toLowerCase()==='rect').forEach(r=>{
      const x=+r.getAttribute('x'),w=+r.getAttribute('width');
      const key=`${x}:${w}`;if(!columns.has(key))columns.set(key,{x,w,marks:[]});columns.get(key).marks.push(r);
    });
    [...columns.values()].forEach(({x,w,marks},i)=>{
      const center=x+w/2;
      children.forEach(m=>{const tag=m.tagName.toLowerCase();if(tag==='circle'&&Math.abs(+m.getAttribute('cx')-center)<w/2)marks.push(m);else if(tag==='text'&&Math.abs(+m.getAttribute('x')-center)<w/2&&+m.getAttribute('y')<base)marks.push(m)});
      const ordered=children.filter(m=>marks.includes(m));
      grow(wrapMarks(svg,ordered),`0px ${base}px`,i*stagger,duration);
    });
  }
  function growPie(svg,cx,cy,duration=730){
    const group=wrapMarks(svg,[...svg.children].filter(m=>['path','circle','text'].includes(m.tagName.toLowerCase())));
    if(!group)return;group.style.transformBox='view-box';group.style.transformOrigin=`${cx}px ${cy}px`;
    motion(group,[{transform:'scale(.04)',opacity:.7},{transform:'scale(1)',opacity:1}],duration);
  }
  function animateStimulus(svg,type,duration=710){
    if(!svg||reduced.matches)return;
    if(type===6)growPie(svg,235,125,duration);else growColumns(svg,222,duration);
  }
  document.addEventListener('tree-stimulus-reveal',e=>animateStimulus(e.detail.svg,e.detail.type,730));

  // The test never reveals the correct answer. The whole stimulus enters together;
  // no bar grows at a different rate and no individual sector is emphasized.
  function trialMotion(){
    const n=++trialGeneration,host=$('trialChart'),graphic=host.querySelector('svg');
    if(!graphic||reduced.matches)return;
    host.classList.remove('motion-ready');void host.offsetWidth;host.classList.add('motion-ready');
    animateStimulus(graphic,trials[current].type,710);
    // Hold submission only while the true, static geometric stimulus arrives.
    const submit=$('submitGuess');submit.disabled=true;
    const release=()=>{if(n!==trialGeneration||$('quiz').hidden)return;const v=$('guessInput').valueAsNumber;submit.disabled=!Number.isFinite(v)||v<0||v>100;};
    setTimeout(release,740);
    motion($('progressLabel'),[{opacity:.35,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],330);
  }
  const oldTrial=showTrial;showTrial=function(){oldTrial();trialMotion()};
  // The original number/slider listeners stay intact; prevent an early submission
  // even when a participant adjusts the slider during the brief reveal.
  let readyAt=0;
  const wrappedTrial=showTrial;showTrial=function(){wrappedTrial();readyAt=reduced.matches?0:performance.now()+740;};
  $('submitGuess').addEventListener('click',e=>{if(performance.now()<readyAt){e.stopImmediatePropagation();e.preventDefault()}},true);

  function researchMotion(){
    if(reduced.matches)return;
    document.querySelectorAll('.research-chart svg').forEach((g,j)=>{
      g.querySelectorAll('.obs-mark').forEach((mark,i)=>{
        const t=90+i*100+j*100;
        fade(mark,t,250);
        mark.querySelectorAll('line').forEach(l=>draw(l,t+80,420));
        mark.querySelectorAll('circle:not([fill=transparent])').forEach(c=>dot(c,t+170));
      });
      g.querySelectorAll('text').forEach((t,i)=>fade(t,Math.min(i*20,210),420));
    });
    const bias=$('biasChart')?.querySelector('svg');if(bias){
      bias.querySelectorAll('line:not([stroke-dasharray])').forEach((l,i)=>draw(l,120+i*150,600));
      bias.querySelectorAll('circle').forEach((c,i)=>{c.style.transformBox='fill-box';c.style.transformOrigin='center';dot(c,170+Math.floor(i/2)*150+(i%2)*90)});
      bias.querySelectorAll('text').forEach((t,i)=>fade(t,Math.min(i*35,350),380));
    }
    // The dot-matrix uses an existing progressive canvas renderer. Accent the summary
    // once the observations have assembled, without changing the numbers.
    document.querySelectorAll('.research-statement strong').forEach((el,i)=>motion(el,[{opacity:.15,transform:'translateY(7px)'},{opacity:1,transform:'translateY(0)'}],400,450+i*80));
  }
  const oldResearch=renderResearch;renderResearch=function(){oldResearch();researchMotion()};

  // First report reveal: both the actual stimulus and the quantitative score bars
  // expand from their respective baselines. Selection updates only the inspector.
  const seenReports=new WeakSet();
  const oldPaint=paintReport;paintReport=function(){
    const previous=$('obsGraphic')?.dataset.obs;oldPaint();
    if(page!==3||reduced.matches)return;
    const list=$('scores'),inspector=$('obsGraphic'),first=list&&!seenReports.has(list);
    if(inspector&&(first||previous!==String(obs))){animateStimulus(inspector.querySelector('svg'),answers[obs].type,760);$('obsValues')?.querySelectorAll('b').forEach((e,i)=>fade(e,160+i*65,350))}
    if(inspector)inspector.dataset.obs=String(obs);
    if(first){seenReports.add(list);list.querySelectorAll('.score i b').forEach((bar,i)=>{bar.style.transformOrigin='left center';motion(bar,[{transform:'scaleX(0)'},{transform:'scaleX(1)'}],840,120+i*65)});
      $('reportPlot')?.querySelectorAll('.obs-mark').forEach((m,i)=>{const l=m.querySelector('line'),c=m.querySelector('circle');draw(l,i*34,520);if(c){c.style.transformBox='fill-box';c.style.transformOrigin='center';dot(c,160+i*34)}});
      document.querySelectorAll('.report-metrics b').forEach((e,i)=>fade(e,i*100,450));}
  };

  function animateOriginal(svg,caseIndex){
    if(!svg)return;
    if(caseIndex===0)growPie(svg,240,123,790);
    else if(caseIndex===1)growColumns(svg,220,800,65);
    else if(caseIndex===2){svg.querySelectorAll('path').forEach((p,i)=>draw(p,80+i*110,820));svg.querySelectorAll('line[stroke-dasharray]').forEach((l,i)=>fade(l,420+i*45,350));svg.querySelectorAll('text').forEach((t,i)=>fade(t,Math.min(i*25,270),350));}
    else svg.querySelectorAll('rect').forEach((r,i)=>{r.style.transformBox='fill-box';r.style.transformOrigin='center';motion(r,[{opacity:0,transform:'scale(.62)'},{opacity:1,transform:'scale(1)'}],510,i*65)});
  }

  function animateRecon(includeBefore=true){
    if(reduced.matches)return;
    const before=$('reconBefore').querySelector('svg'),target=$('reconAfter').querySelector('svg');
    if(includeBefore&&before)animateOriginal(before,rc);
    if(!target)return;
    const from=includeBefore?180:0;
    if(reformed&&(rc===0||rc===1)){
      // Each final dot travels from its original data mark to a shared-scale location.
      const points=[...target.querySelectorAll('circle')];
      const origins=[];
      if(rc===0){let start=0;recon[0].data.forEach(v=>{const a=(start+v*1.8-90)*Math.PI/180;origins.push([240+Math.cos(a)*74,123+Math.sin(a)*74]);start+=v*3.6})}
      else recon[1].data.forEach((group,i)=>{let y=220;group.forEach(v=>{let height=v*3.2;y-=height;origins.push([128+i*118,y+height/2])});origins.push([128+i*118,y])});
      points.forEach((c,i)=>{const start=origins[i];if(!start)return;const x=Number(c.getAttribute('cx')),y=Number(c.getAttribute('cy'));motion(c,[{opacity:0,transform:`translate(${start[0]-x}px,${start[1]-y}px)`},{opacity:1,transform:'translate(0px,0px)'}],760,from+i*35)});
      target.querySelectorAll('line').forEach(l=>fade(l,from,300));target.querySelectorAll('text').forEach(t=>fade(t,from+220,430));
    }else if(rc===2){
      target.querySelectorAll('path').forEach((p,i)=>draw(p,from+i*100,820));target.querySelectorAll('circle').forEach((c,i)=>dot(c,from+80+i*90));target.querySelectorAll('text').forEach((t,i)=>fade(t,from+Math.min(i*30,400),330));
    }else if(rc===3&&reformed){
      target.querySelectorAll('rect').forEach((r,i)=>{if(r.getAttribute('fill')!=='none'){r.style.transformBox='fill-box';r.style.transformOrigin='50% 100%';motion(r,[{transform:'scaleY(0)',opacity:.6},{transform:'scaleY(1)',opacity:1}],620,from+i*35)}else fade(r,from,250)});
    }else animateOriginal(target,rc);
    const data=$('reconData');data.classList.remove('flash');void data.offsetWidth;data.classList.add('flash');
  }
  const oldRecon=renderRecon;renderRecon=function(){oldRecon();animateRecon()};
  $('reconToggle').onclick=()=>{reformed=!reformed;oldRecon();animateRecon(false)};

  // Replay chart introductions only when entering their own chapter.
  const oldShowPage=showPage;showPage=function(i){oldShowPage(i);if(page===6){oldRecon();animateRecon()}if(page===7||page===2){const a=pages[page].querySelector('.collage-asset');if(a){a.style.animation='none';void a.offsetWidth;a.style.animation=''}}};
  if(page===3&&answers.length===14)paintReport();if(page===5)researchMotion();if(page===6)animateRecon();

  // The yellow disk is its own parallax layer behind the stationary cutouts.
  // Restore the original photograph, including its fine hair and paper edges,
  // using a colour-keyed foreground within the disk's original footprint.
  const hero=document.querySelector('.hero-art');
  if(hero){
    const papers='M1123 322 L1125 280 L1142 246 L1156 211 L1195 193 L1189 156 L1283 120 L1297 144 L1335 135 L1407 117 L1439 148 L1440 186 L1434 226 L1488 215 L1548 192 L1560 214 L1574 261 L1585 309 L1578 356 L1564 407 L1541 483 L1487 479 L1432 464 L1427 493 L1440 519 L1360 545 L1351 524 L1311 520 L1276 507 L1227 480 L1228 446 L1231 411 L1206 391 L1199 360 L1177 344 L1152 333 L1137 334 Z';
    const person='M607 818 L621 761 L651 711 L696 676 L705 659 L680 637 L665 597 L646 561 L646 522 L664 492 L684 476 L695 431 L715 396 L747 362 L777 347 L817 320 L855 292 L891 279 L925 286 L947 312 L950 325 L981 318 L998 327 L1027 326 L1046 336 L1071 332 L1094 334 L1110 347 L1134 334 L1161 330 L1188 343 L1206 368 L1212 415 L1218 471 L1246 524 L1276 558 L1311 601 L1351 643 L1376 681 L1415 704 L1448 755 L1438 818 Z';
    hero.innerHTML=`<svg class="hero-layered" viewBox="610 115 980 690" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><defs><clipPath id="heroPaperCut"><path d="${papers}"/></clipPath><clipPath id="heroForegroundCut"><path d="${person}"/></clipPath><filter id="heroYellowKey" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  -4 0 4 1 .55"/></filter><radialGradient id="heroDisk"><stop offset="0" stop-color="#ffbe00"/><stop offset="1" stop-color="#ffc000"/></radialGradient></defs><image href="collage.png" width="1671" height="941"/><circle cx="966" cy="454" r="326" fill="#f3e6d7"/><circle class="hero-disk-layer" cx="966" cy="454" r="312" fill="url(#heroDisk)"/><g clip-path="url(#heroForegroundCut)"><image href="collage.png" width="1671" height="941" filter="url(#heroYellowKey)"/></g><g clip-path="url(#heroPaperCut)"><image href="collage.png" width="1671" height="941"/></g></svg>`;
    hero.classList.add('is-layered');
  }

  // Low-amplitude optical parallax: selected artwork follows the pointer, then settles.
  // The actual charts and explanatory text never move with the mouse.
  if(matchMedia('(hover:hover) and (pointer:fine)').matches){
    document.querySelectorAll('.hero-art,.lab-art,.end-shape').forEach(el=>{
      const host=el.closest('.page');if(!host)return;
      const reset=()=>{el.style.setProperty('--move-x','0px');el.style.setProperty('--move-y','0px');el.style.setProperty('--tilt','0deg');el.style.setProperty('--shine-x','50%');el.style.setProperty('--shine-y','50%')};
      host.addEventListener('pointermove',event=>{if(reduced.matches||el.closest('[hidden]'))return;const r=host.getBoundingClientRect(),x=Math.max(-1,Math.min(1,(event.clientX-r.left)/r.width*2-1)),y=Math.max(-1,Math.min(1,(event.clientY-r.top)/r.height*2-1));const layered=el.classList.contains('is-layered');el.style.setProperty('--move-x',`${x*(layered?32:12)}px`);el.style.setProperty('--move-y',`${y*(layered?24:9)}px`);el.style.setProperty('--tilt',`${x*(layered?0:1.15)}deg`);el.style.setProperty('--shine-x',`${50+x*15}%`);el.style.setProperty('--shine-y',`${50+y*15}%`)});
      host.addEventListener('pointerleave',reset);host.addEventListener('pointercancel',reset);
    });
  }
})();
