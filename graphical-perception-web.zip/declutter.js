/* Keep the visual hierarchy clear without removing research context. */
(() => {
  const one=(selector)=>document.querySelector(selector);
  const text=(selector,value)=>{const el=one(selector);if(el)el.textContent=value};
  const remove=(selector)=>document.querySelectorAll(selector).forEach(el=>el.remove());
  remove('.hero-intro, .hero-actions kbd, .personal .chapter p, .atlas .chapter p, .lab .chapter p, .redesign .chapter p');
  text('.lab-copy p','以 A 为 100%，估计 B 的比例。');
  text('.lab-copy small','随机比例 · 非原实验复现');
  text('.answer p','凭直觉，不测量。');
  text('#finished p','已完成 14 次判断');
  text('.evidence .chapter p','每组 51 位有效受试者');
  text('.end-text p','理解感知，才能更好地设计信息。');
  text('.range-footer > span','');
  remove('.atlas-overline');
  $('specEnglish').hidden=true;
  text('.atlas-legend > span:nth-child(2)','环带：6 级理论排序');
  const atlasCaption=one('.editorial-atlas > text:last-child');
  if(atlasCaption?.textContent==='十种视觉表达')atlasCaption.remove();
  const oldIntroReveal=$('introReveal').onclick;
  $('introReveal').onclick=function(e){oldIntroReveal?.call(this,e);$('introFeedback').textContent=''};
  const reset=resetIntro;resetIntro=function(){reset();$('introFeedback').textContent='黑色为参照'};
  if(!$('intro').classList.contains('revealed'))$('introFeedback').textContent='黑色为参照';
  function tidyPersonal(){
    const body=$('personalBody');
    body.querySelectorAll('.score em').forEach(el=>el.remove());
    const note=body.querySelector('#reportPlot + .fine');
    if(note)note.textContent='左低估 · 右高估 · 点击查看';
    const metric=body.querySelector('.report-metrics > div:last-child span');
    if(metric)metric.textContent='判断次数';
  }
  const oldPersonal=renderPersonal;renderPersonal=function(){oldPersonal();tidyPersonal()};
  const oldPaint=paintReport;paintReport=function(){oldPaint();tidyPersonal()};
  function tidyResearch(){
    const insight=$('researchInsight'),box=$('researchContent');
    if(researchTab===3){
      insight.innerHTML='<b>2 项实验</b><span>7 类判断 · 130 个实验单元</span>';
    }else if(researchTab===0){
      insight.querySelector('span')?.remove();
      const tool=box.querySelector('.research-tools > span');
      if(tool)tool.textContent='对数绝对误差 · 越小越准确';
      const ci=box.querySelector('.research-tools label');
      if(ci?.lastChild?.nodeType===3)ci.lastChild.nodeValue=' 95% 置信区间';
      const focus=$('researchFocus');
      if(focus)focus.textContent='图表近似读数；倍率据原文，两组独立解读。';
    }else if(researchTab===1){
      const tool=box.querySelector('.research-tools > span');
      if(tool)tool.textContent='每点一次判断';
    }else if(researchTab===2){
      const labels=['长度 · 不同基线','长度 · 同一堆叠','角度 · 饼图'];
      box.querySelectorAll('.bias-simple-row').forEach((row,i)=>{
        const label=row.querySelector('.bias-simple-label');
        const name=label?.querySelector('strong');
        if(name)name.textContent=labels[i];
        label?.querySelector('.bias-simple-glyph')?.remove();
        label?.querySelector('small')?.remove();
      });
      const note=box.querySelector('.bias-footer');
      if(note)note.textContent='偏差据原文；平均误差为近似读数。统计口径不同，不可相减。';
    }
  }
  const oldResearch=renderResearch;renderResearch=function(){oldResearch();tidyResearch()};
  function tidyRecon(){
    remove('#reconChallenge .eyebrow, .recon-placeholder .mono');
    const answer=one('#reconChallenge .challenge-result');
    if(answer&&!reformed){
      // Reserve the exact answer's space before revealing it, so line wrapping
      // cannot move the challenge row or the rest of the centered page.
      const c=challenges[rc];
      answer.textContent=(challengePick?(challengePick===c.answer?'判断正确。':'你的判断：'+challengePick+'。正确答案：'+c.answer+'。'):'答案：'+c.answer+'。')+c.explain;
      answer.classList.add('recon-answer-pending');
      answer.setAttribute('aria-hidden','true');
    }
    text('.recon-body > div:first-child .data-header > span:first-child','原图');
    text('.recon-right .data-header > span:first-child','重构');
  }
  const oldRecon=renderRecon;renderRecon=function(){oldRecon();tidyRecon()};
  const oldShow=showPage;showPage=function(i){oldShow(i);if(i===6)tidyRecon()};
  tidyPersonal();if(page===5)tidyResearch();tidyRecon();
})();
