/* Paper-based experiment tree. Every leaf is a real experimental unit, not a simulated person. */
(() => {
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  // Fig. 11: panel headings transcribed exactly; y values read approximately from plotted marks.
  const aRatio=[82.5,82.5,68.1,68.1,56.2,46.4,46.4,38.3,26.1,17.8];
  const aError=[[1.4,2.2,2.1,2.6,2.4],[1.4,1.4,1.4,2.0,2.5],[2.0,2.3,2.1,3.0,3.2],[2.0,2.1,2.1,2.4,3.1],[1.5,1.6,2.4,2.5,2.7],[.8,1.1,2.1,2.5,3.4],[1.2,1.5,1.8,2.1,3.0],[1.5,2.5,1.6,2.4,2.9],[.9,1.1,1.2,2.0,2.4],[1.4,1.4,1.5,1.8,1.5]];
  // Fig. 14, approximate coordinate reads in increasing x; one overlapping mark per panel
  // is not given an invented coordinate. The sorted index is not an original trial number.
  const bAngle=[[9.9,-.8],[10.9,.4],[12.5,1.4],[12.7,1.5],[13.8,1.3],[15.8,1.1],[20.2,.9],[23.4,1.7],[27,2.2],[30.1,1.1],[30.2,2.3],[34.3,2.2],[36.4,2.5],[37.9,2.2],[42,2.1],[42.3,2.3],[46.7,2.4],[48.6,3.3],[50.1,2.7],[50.4,1.0],[52.2,2.5],[52.8,2.3],[54.6,2.3],[58.4,2.8],[61.1,2.9],[62.1,2.6],[65.7,3.4],[71.4,3.0],[72.2,2.9],[77.4,2.4],[78.7,2.4],[79.7,2.2],[85.5,2.4],[87.2,2.4],[87.3,2.6],[93.2,3.0],[98.7,.9],[99.3,1.2],[99.8,.6]];
  const bPosition=[[10.2,-1.8],[11.2,1.0],[12.8,1.4],[13,1.4],[14.1,1.2],[16.1,1.4],[20.3,0],[23.6,1.5],[27.2,1.3],[30.4,.2],[30.4,.6],[34.5,2.2],[36.6,1.9],[38.2,1.6],[42.1,1.5],[42.4,1.4],[47,1.6],[48.9,.7],[50.2,.9],[50.7,-.8],[52.5,1.1],[53.2,1.5],[55,.9],[58.7,1.3],[61.3,.7],[62.3,1.0],[65.9,2.3],[71.4,1.5],[72.4,1.6],[77.6,1.5],[78.7,1.6],[79.7,.4],[85.5,.5],[87.2,1.4],[87.5,2.2],[93.2,1.5],[98.9,.1],[99.5,-.4],[99.7,-.2]];
  const types=[
    ['A1','近距位置',0,'A','共同基线、相邻两柱',[-1.10,-.68,-.08]],
    ['A2','堆叠底部',1,'A','两根堆叠柱的底部分段',[-1.50,-.17,.12]],
    ['A3','远距位置',2,'A','共同基线、间隔较远的两柱',[-1.43,.39,-.12]],
    ['A4','不同基线长度',3,'A','两根堆叠柱顶部的分段',[-.86,.78,.14]],
    ['A5','同一堆叠长度',4,'A','同一堆叠柱中的相邻分段',[-.12,.85,-.10]],
    ['B1','柱状图位置',5,'B','其余柱体与最大柱体的比例',[1.07,-.64,.12]],
    ['B2','饼图角度',6,'B','其余扇区与最大扇区的比例',[1.15,.60,-.14]]
  ];
  const nodes=[],lookup=new Map(),fmt=x=>x.toLocaleString('en-US'),pad=x=>String(x).padStart(2,'0');
  function add(n){nodes.push(n);lookup.set(n.id,n);return n}
  add({id:'root',kind:'root',name:'图形感知实验',pos:[0,0,0],count:6630,units:130});
  add({id:'A',kind:'experiment',name:'实验 A',subtitle:'位置—长度',parent:'root',group:'A',pos:[-.49,-.11,.02],count:2550,units:50});
  add({id:'B',kind:'experiment',name:'实验 B',subtitle:'位置—角度',parent:'root',group:'B',pos:[.49,-.02,-.02],count:4080,units:80});
  const phi=Math.PI*(3-Math.sqrt(5));
  types.forEach(([id,name,type,group,desc,pos])=>{
    const N=group==='A'?10:40,stat=group==='A'?fig16A[type]:fig16B[type-5];
    add({id,kind:'type',name,type,group,desc,parent:group,pos,count:N*51,units:N,stat});
    for(let i=0;i<N;i++){
      const values=group==='A'?[aRatio[i],aError[i][type]]:(type===5?bPosition:bAngle)[i];
      const y=1-2*(i+.5)/N,r=Math.sqrt(1-y*y),theta=phi*i+type*.75,radius=group==='A'?.25:.44;
      const radial=radius*(.66+.34*Math.sqrt(((i*17)%N+.5)/N));
      add({id:`${id}-${pad(i+1)}`,kind:'unit',name:`${id} · ${pad(i+1)}`,type,group,parent:id,index:i,ratio:values?(group==='B'&&i===0?10:group==='B'&&i===38?99.7:values[0]):undefined,error:values?.[1],pos:[pos[0]+Math.cos(theta)*r*radial*1.15,pos[1]+y*radial*.85,pos[2]+Math.sin(theta)*r*radial],count:51,units:1});
    }
  });
  const oldResearch=renderResearch;let cleanup=null;
  function drawTree(){
    cleanup?.();const box=$('researchContent');document.querySelectorAll('[data-research]').forEach(b=>b.classList.toggle('active',+b.dataset.research===3));
    $('researchInsight').innerHTML='<b>6,630 次判断</b><span>2 项实验 · 7 类判断 · 130 个实验单元</span>';
    const edgeHtml=nodes.filter(n=>n.parent).map(n=>`<line class="tree-edge" data-edge="${n.id}"/>`).join('');
    const nodeHtml=nodes.map(n=>{const rad=n.kind==='root'?14:n.kind==='experiment'?10:n.kind==='type'?7.2:3.2;const color=n.group==='B'?'#ffbf00':n.kind==='root'?'#ffffff':n.kind==='experiment'?'#eee6d4':n.kind==='type'?'#d5cbbb':'#c3bfb6';const label=n.kind==='root'?'研究总览':n.kind==='experiment'?n.name:n.kind==='type'?`${n.id} ${n.name}`:'';const title=n.kind==='unit'?`${n.name}，${n.ratio===undefined?'重叠点，读数未分离':`${n.group==='A'?'':'约'}${n.ratio}%，误差约 ${n.error.toFixed(1)}`}`:`${n.name}，${fmt(n.count)} 次判断`;return `<g class="tree-node tree-${n.kind}" data-node="${n.id}" role="button" tabindex="0" aria-label="${title}" aria-pressed="false" style="--node-color:${color}"><title>${title}</title><circle class="tree-halo" r="${rad+4}"/><circle class="tree-dot" r="${rad}"/><circle class="tree-hit" r="${Math.max(8,rad+3)}"/>${label?`<text class="tree-label" x="${n.kind==='root'?0:rad+5}" y="${n.kind==='root'?-22:-rad-4}" text-anchor="${n.kind==='root'?'middle':'start'}">${label}</text>`:''}</g>`}).join('');
    box.innerHTML=`<div class="network-study tree-study"><div class="network-stage"><div class="network-meta"><span title="130 个实验单元，每个单元汇总 51 次判断。图中位置仅表示层级，不表示数值。">EXPERIMENT TREE / 1984</span><span><span class="tree-legend-a"><i></i>A 位置—长度</span><span class="tree-legend-b"><i></i>B 位置—角度</span></span></div><div class="tree-field"><svg id="studyTree" viewBox="0 0 800 350" role="group" aria-label="三维实验树，所有节点可点击，拖动旋转、滚轮缩放"><g class="tree-links">${edgeHtml}</g><g class="tree-nodes">${nodeHtml}</g></svg><div id="treeTip" class="tree-tip" hidden></div></div><div class="network-toolbar"><span id="treeHint">点击节点了解详情 · 拖动旋转</span><div><button id="treeMinus" aria-label="缩小">−</button><button id="treePlus" aria-label="放大">+</button><button id="treeSpin" aria-pressed="false">旋转</button><button id="treeReset">复位</button></div></div></div><aside id="treeDetail" class="tree-detail" aria-live="polite"></aside></div>`;
    const field=$('studyTree'),detail=$('treeDetail'),tip=$('treeTip'),nodeEls=new Map([...field.querySelectorAll('[data-node]')].map(el=>[el.dataset.node,el])),edgeEls=new Map([...field.querySelectorAll('[data-edge]')].map(el=>[el.dataset.edge,el]));
    field.setAttribute('aria-label','三维交互式力导向实验图，拖动空白处旋转，拖动节点回弹，点击查看数据');
    $('treeHint').textContent='拖动空白处旋转 · 点击/拖动节点';
    $('treeSpin').textContent='自动旋转';$('treeSpin').setAttribute('aria-pressed','false');
    const replayButton=document.createElement('button');replayButton.textContent='重演展开';replayButton.title='逐层展开实验、判断类型与实验单元';replayButton.id='treeReplay';$('treeReset').before(replayButton);
    field.closest('.network-stage').querySelector('.network-meta>span').textContent='EXPERIMENT GALAXY / 1984';
    for(const n of nodes){if(n.kind==='unit')continue;const el=nodeEls.get(n.id),r=n.kind==='root'?18:n.kind==='experiment'?15:12;el.querySelector('.tree-dot').setAttribute('r',r);el.querySelector('.tree-halo').setAttribute('r',r+4);el.querySelector('.tree-hit').setAttribute('r',r+3);const label=el.querySelector('.tree-label');label.setAttribute('x',0);label.setAttribute('y',-r-7);label.setAttribute('text-anchor','middle');label.textContent=n.kind==='type'?n.name:n.kind==='root'?'研究总览':n.name;const code=document.createElementNS('http://www.w3.org/2000/svg','text');code.setAttribute('class','tree-code');code.setAttribute('text-anchor','middle');code.setAttribute('dominant-baseline','central');code.textContent=n.kind==='root'?'总':n.id;el.append(code);}
    let selected='root',hover=null,yaw=0,pitch=0,zoom=1,drag=null,spinning=false,raf=0,dead=false,last=0,ignoreClick=false,energy=0,replayAt=null;
    const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));const ancestor=(id,target)=>{let n=lookup.get(id);while(n){if(n.id===target)return true;n=lookup.get(n.parent)}return false};
    const children=id=>nodes.filter(n=>n.parent===id);
    // Meaningful hierarchy only: links represent the actual experimental design.
    // Spring forces, node repulsion and weak positional anchors settle the clusters.
    const hubs={root:[400,175],A:[317,175],B:[486,175],A1:[244,67],A2:[139,121],A3:[147,239],A4:[253,289],A5:[347,277],B1:[603,88],B2:[603,262]};
    const states=new Map();
    for(const n of nodes){let x,y;if(n.kind==='unit'){const p=hubs[n.parent],N=n.group==='A'?10:40,t=n.index*phi+n.type*.91,r=(n.group==='A'?37:66)*(.32+.68*Math.sqrt((n.index+.8)/N));x=p[0]+Math.cos(t)*r*1.13;y=p[1]+Math.sin(t)*r;}else [x,y]=hubs[n.id];const z=n.pos[2]*190;states.set(n.id,{x,y,z,ax:x,ay:y,az:z,vx:0,vy:0,vz:0,n});}
    const project=n=>{const p=states.get(n.id),x=p.x-400,y=p.y-175,z=p.z,ca=Math.cos(yaw),sa=Math.sin(yaw),cb=Math.cos(pitch),sb=Math.sin(pitch),xx=x*ca+z*sa,zz=z*ca-x*sa,yy=y*cb-zz*sb,depth=y*sb+zz*cb,f=680/(680-depth);return{x:400+xx*zoom*f,y:175+yy*zoom*f,z:depth,f}};
    function point(e){const p=field.createSVGPoint();p.x=e.clientX;p.y=e.clientY;return p.matrixTransform(field.getScreenCTM().inverse())}
    function dragPosition(dx,dy){const ca=Math.cos(yaw),sa=Math.sin(yaw),cb=Math.cos(pitch),sb=Math.sin(pitch);return {x:dx*ca+dy*sa*sb,y:dy*cb,z:dx*sa-dy*ca*sb}}
    function wake(a=1){energy=Math.max(energy,a);if(!raf&&!dead)raf=requestAnimationFrame(tick)}
    function step(){const all=[...states.values()];for(const p of all){const k=p.n.kind==='unit'?.025:.045;p.vx+=(p.ax-p.x)*k;p.vy+=(p.ay-p.y)*k;}
      for(const p of all){if(!p.n.parent)continue;const q=states.get(p.n.parent),dx=q.x-p.x,dy=q.y-p.y,d=Math.max(.01,Math.hypot(dx,dy)),ideal=Math.hypot(q.ax-p.ax,q.ay-p.ay),f=(d-ideal)*.035;p.vx+=dx/d*f;p.vy+=dy/d*f;q.vx-=dx/d*f*.38;q.vy-=dy/d*f*.38;}
      for(let i=0;i<all.length;i++)for(let j=i+1;j<all.length;j++){const p=all[i],q=all[j],dx=p.x-q.x,dy=p.y-q.y,d=Math.max(.1,Math.hypot(dx,dy)),min=(p.n.kind==='unit'?8:21)+(q.n.kind==='unit'?8:21);if(d<min){const f=(min-d)*.055;p.vx+=dx/d*f;p.vy+=dy/d*f;q.vx-=dx/d*f;q.vy-=dy/d*f;}}
      for(const p of all){if(drag?.moved&&drag.id===p.n.id){p.x=drag.tx;p.y=drag.ty;p.z=drag.tz;p.vx=p.vy=p.vz=0;continue;}p.vx*=.78;p.vy*=.78;p.vz=(p.vz+(p.az-p.z)*.045)*.78;p.x=clamp(p.x+p.vx,18,782);p.y=clamp(p.y+p.vy,18,332);p.z=clamp(p.z+p.vz,-240,240);}
    }
    function endReplay(){replayAt=null;field.classList.remove('replaying');for(const p of states.values()){p.x=p.ax;p.y=p.ay;p.z=p.az;p.vx=p.vy=p.vz=0;nodeEls.get(p.n.id).style.opacity='';nodeEls.get(p.n.id).style.pointerEvents='';if(p.n.parent)edgeEls.get(p.n.id).style.opacity='';}replayButton.textContent='重演展开';$('treeHint').textContent='拖动空白处旋转 · 点击/拖动节点';wake(.8);}
    function replay(){stopSpin();selected='root';hover=null;yaw=0;pitch=0;zoom=1;energy=0;renderDetail();if(reduced.matches){endReplay();draw();return;}field.classList.add('replaying');replayAt=performance.now();replayButton.textContent='展开中…';replayFrame(replayAt);draw();wake(.01);}
    function replayFrame(t){const elapsed=t-replayAt;if(elapsed>=3400){endReplay();return;}const phase=elapsed<600?'01 / 研究总览':elapsed<1400?'02 / 两项实验':elapsed<2200?'03 / 七类判断':'04 / 130 个实验单元';$('treeHint').textContent=phase;for(const p of states.values()){const n=p.n,delay=n.kind==='root'?0:n.kind==='experiment'?450:n.kind==='type'?1100+types.findIndex(a=>a[0]===n.id)*65:1900+n.index*24,span=n.kind==='unit'?550:700,progress=clamp((elapsed-delay)/span,0,1),e=1-Math.pow(1-progress,3),q=states.get(n.parent)||p;p.x=q.ax+(p.ax-q.ax)*e;p.y=q.ay+(p.ay-q.ay)*e;p.z=q.az+(p.az-q.az)*e;const opacity=n.kind==='root'?1:Math.min(1,progress*3);const el=nodeEls.get(n.id);el.style.opacity=opacity;el.style.pointerEvents=progress<.7?'none':'';if(n.parent)edgeEls.get(n.id).style.opacity=opacity*.55;}}
    function draw(){
      const projected=new Map(nodes.map(n=>[n.id,project(n)]));
      const focus=hover||selected;
      nodes.forEach(n=>{const p=projected.get(n.id),el=nodeEls.get(n.id),on=focus==='root'||ancestor(n.id,focus)||ancestor(focus,n.id);el.setAttribute('transform',`translate(${p.x.toFixed(1)} ${p.y.toFixed(1)}) scale(${clamp(p.f,.65,1.55).toFixed(3)})`);el.classList.toggle('dim',!on);el.classList.toggle('picked',n.id===selected);el.classList.toggle('hovered',n.id===hover);el.setAttribute('aria-pressed',String(n.id===selected));if(n.parent){const q=projected.get(n.parent),edge=edgeEls.get(n.id);edge.setAttribute('x1',q.x);edge.setAttribute('y1',q.y);edge.setAttribute('x2',p.x);edge.setAttribute('y2',p.y);edge.classList.toggle('dim',!on);edge.classList.toggle('lit',focus!=='root'&&on);edge.style.stroke=n.group==='B'?'#d7aa26':'#e3d7c0';}});
      // Keep the SVG focus order stable while rotating and hovering.
      if(hover){const n=lookup.get(hover),p=projected.get(hover);tip.hidden=false;tip.textContent=n.kind==='unit'?`${n.name} · ${n.ratio===undefined?'重叠点':`真实比例 ${n.group==='A'?'':'≈'}${n.ratio}% · 误差 ≈${n.error.toFixed(1)}`}`:`${n.name} · ${fmt(n.count)} 次判断`;tip.style.left=`${clamp(p.x/8,9,91)}%`;tip.style.top=`${clamp(p.y/3.5-6,8,85)}%`;}else tip.hidden=true;
    }
    function stopSpin(){spinning=false;$('treeSpin').textContent='自动旋转';$('treeSpin').setAttribute('aria-pressed','false')}
    function jump(id){if(!lookup.has(id))return;if(replayAt!==null)endReplay();selected=id;hover=null;stopSpin();renderDetail();draw()}
    function childButtons(list){return `<div class="tree-choices">${list.map(n=>`<button data-jump="${n.id}"><i class="${n.group==='B'?'yellow':''}"></i><span><b>${n.name}</b>${n.subtitle?`<small>${n.subtitle}</small>`:''}</span><strong>${fmt(n.count)}</strong></button>`).join('')}</div>`}
    function renderDetail(){
      const n=lookup.get(selected),parent=lookup.get(n.parent),type=n.kind==='unit'?parent:n,crumb=n.kind==='root'?'研究总览':`<button data-jump="root">总览</button> / ${n.kind==='experiment'?n.name:`<button data-jump="${n.group}">实验 ${n.group}</button> / ${n.kind==='unit'?`<button data-jump="${parent.id}">${parent.id}</button> / ${pad(n.index+1)}`:n.id}`}`;
      let html=`<div class="tree-breadcrumb">${crumb}</div>`;
      if(n.kind==='root')html+=`<div class="tree-title">实验全景</div><div class="tree-number">6,630<small>次判断</small></div>${childButtons(children('root'))}<p class="tree-help">点击节点查看数据。</p><button class="tree-result" data-result="0">比较实验结果</button>`;
      else if(n.kind==='experiment')html+=`<div class="tree-title">${n.name} · ${n.subtitle}</div><div class="tree-number">${fmt(n.count)}<small>次判断</small></div><p>51 位有效受试者 × ${n.units} 个实验单元</p>${childButtons(children(n.id))}<p class="tree-help">${n.id==='A'?'5 种判断类型，每种包含 10 组比值。':'两种编码分别判断 40 个比值。'}</p>`;
      else{
        const members=children(type.id),isUnit=n.kind==='unit',valid=isUnit&&n.ratio!==undefined,ratio=valid?n.ratio:60;
        html+=`<div class="tree-title">${type.id} · ${type.name}</div><p>${type.desc}</p>`;
        if(isUnit)html+=`<div class="tree-stats"><div><span>真实比例</span><b>${valid?`${n.group==='A'?'':'≈'}${n.ratio}%`:'—'}</b></div><div><span>对数绝对误差中间均值</span><b>${valid?`≈${n.error.toFixed(1)}`:'—'}</b></div></div><p class="tree-small">${n.group==='A'?`图 11 · 面板 ${pad(n.index+1)}`:`图 14 · ${type.type===5?'位置':'角度'}面板 · ${valid?`读图点 ${pad(n.index+1)}`:'未分离点'}`} · 51 次判断${valid?'':' · 读数不可靠，未估值'}</p>`;
        else html+=`<div class="tree-stats"><div><span>判断次数</span><b>${fmt(n.count)}</b></div><div><span>平均对数误差</span><b>≈${n.stat[0].toFixed(2)}</b></div></div><p class="tree-small">${n.units} 个实验单元 · 图 16（95% CI ≈ ${n.stat[1].toFixed(2)}–${n.stat[2].toFixed(2)}）</p>`;
        html+=`<div class="tree-stimulus">${valid||!isUnit?trialGraphic({type:type.type,ratio}):'<p>原图重叠，暂无可靠的比例读数。</p>'}</div><p class="tree-small">${valid?'按真实比例重绘的刺激图示意，非原始试题。':!isUnit?'60% 比例示例，用于理解该判断类型。':'该实验单元仍计入原文总数。'}</p><label class="tree-unit-picker"><span>选择实验单元</span><select id="treeUnitSelect" aria-label="选择该判断类型的实验单元"><option value="${type.id}" ${!isUnit?'selected':''}>类型概览</option>${members.map(m=>`<option value="${m.id}" ${m.id===selected?'selected':''}>${pad(m.index+1)} · ${m.ratio===undefined?'重叠点未读出':`${m.group==='A'?'':'≈'}${m.ratio}%`}</option>`).join('')}</select></label>`;
      }
      detail.innerHTML=html;detail.dataset.kind=n.kind;detail.querySelectorAll('[data-jump]').forEach(b=>b.onclick=()=>jump(b.dataset.jump));detail.querySelectorAll('[data-result]').forEach(b=>b.onclick=()=>{researchTab=+b.dataset.result;renderResearch()});const picker=$('treeUnitSelect');if(picker)picker.onchange=()=>jump(picker.value);
      if(!reduced.matches){
        detail.querySelectorAll('.tree-number,.tree-stats b,.tree-choices strong').forEach((el,i)=>{const t=el.firstChild;if(t?.nodeType!==3)return;const original=t.nodeValue.trim(),m=original.match(/^(≈?)(-?[\d,]+(?:\.\d+)?)(%?)$/);if(!m)return;const value=Number(m[2].replaceAll(',','')),digits=m[2].includes('.')?m[2].split('.')[1].length:0,grouped=m[2].includes(','),start=performance.now()+Math.min(120,i*35);const paint=now=>{if(!el.isConnected)return;const p=clamp((now-start)/700,0,1),v=value*(1-Math.pow(1-p,3)),shown=digits?v.toFixed(digits):grouped?fmt(Math.round(v)):String(Math.round(v));t.nodeValue=p===1?original:m[1]+shown+m[3];if(p<1)requestAnimationFrame(paint)};paint(performance.now())});
        detail.querySelectorAll('.tree-title,.tree-help,.tree-choices,.tree-stats,.tree-stimulus,.tree-unit-picker').forEach((el,i)=>el.animate([{opacity:0,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:360,delay:Math.min(100,i*25),easing:'ease-out',fill:'backwards'}));
        const stimulus=detail.querySelector('.tree-stimulus svg');if(stimulus)document.dispatchEvent(new CustomEvent('tree-stimulus-reveal',{detail:{svg:stimulus,type:type.type}}));
      }
    }
    function hoverNode(id){if(drag||spinning)return;if(hover===id)return;hover=id;draw()}
    field.addEventListener('pointerover',e=>{const el=e.target.closest('[data-node]');if(el)hoverNode(el.dataset.node)});
    field.addEventListener('pointerout',e=>{if(!e.relatedTarget?.closest?.('[data-node]'))hoverNode(null)});
    field.addEventListener('focusin',e=>{const el=e.target.closest('[data-node]');if(el)hoverNode(el.dataset.node)});field.addEventListener('focusout',()=>hoverNode(null));
    field.addEventListener('click',e=>{if(ignoreClick){ignoreClick=false;return}const el=e.target.closest('[data-node]');if(el)jump(el.dataset.node);else{jump('root');replay()}});
    field.addEventListener('keydown',e=>{const el=e.target.closest('[data-node]');if(el&&['Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();jump(el.dataset.node)}else if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();e.stopPropagation();stopSpin();yaw+=(e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0)*.15;pitch=clamp(pitch+(e.key==='ArrowDown'?1:e.key==='ArrowUp'?-1:0)*.15,-1.35,1.35);draw()}});
    field.addEventListener('pointerdown',e=>{if(replayAt!==null){endReplay();draw()}const el=e.target.closest('[data-node]'),p=point(e),id=el?.dataset.node,s=id?states.get(id):null;stopSpin();drag={id,ox:e.clientX,oy:e.clientY,px:p.x,py:p.y,x:e.clientX,y:e.clientY,moved:false};if(s)Object.assign(drag,{sx:s.x,sy:s.y,sz:s.z,tx:s.x,ty:s.y,tz:s.z,f:project(s.n).f});ignoreClick=false;});
    field.addEventListener('pointermove',e=>{if(!drag)return;if(!drag.moved&&Math.hypot(e.clientX-drag.ox,e.clientY-drag.oy)<4)return;if(!drag.moved){drag.moved=true;field.setPointerCapture(e.pointerId);field.classList.add('dragging');hover=null;}if(drag.id){const p=point(e),d=dragPosition((p.x-drag.px)/(zoom*drag.f),(p.y-drag.py)/(zoom*drag.f));drag.tx=clamp(drag.sx+d.x,18,782);drag.ty=clamp(drag.sy+d.y,18,332);drag.tz=clamp(drag.sz+d.z,-240,240);wake()}else{yaw+=(e.clientX-drag.x)*.009;pitch=clamp(pitch+(e.clientY-drag.y)*.008,-1.35,1.35);draw()}drag.x=e.clientX;drag.y=e.clientY;});
    const end=()=>{if(drag?.moved){ignoreClick=true;wake(1.5)}drag=null;field.classList.remove('dragging')};field.addEventListener('pointerup',end);field.addEventListener('pointercancel',end);field.addEventListener('pointerleave',()=>{if(!drag?.moved){drag=null;hoverNode(null)}});
    field.addEventListener('wheel',e=>{e.preventDefault();e.stopPropagation();zoom=clamp(zoom*Math.exp(-e.deltaY*.001),.7,2.6);draw()},{passive:false});
    $('treePlus').onclick=()=>{zoom=clamp(zoom*1.2,.7,2.6);draw()};$('treeMinus').onclick=()=>{zoom=clamp(zoom/1.2,.7,2.6);draw()};$('treeReset').onclick=()=>{yaw=0;pitch=0;zoom=1;jump('root');endReplay();draw()};
    $('treeReplay').onclick=()=>replay();$('treeSpin').onclick=()=>{if(spinning){stopSpin();return;}if(replayAt!==null)endReplay();spinning=true;last=0;hover=null;$('treeSpin').textContent='暂停旋转';$('treeSpin').setAttribute('aria-pressed','true');wake(.03)};
    function tick(t){raf=0;if(dead||!field.isConnected)return;if(replayAt!==null)replayFrame(t);else if(energy>.025||drag?.moved){step();step();energy*=.96;}if(spinning){if(last)yaw+=Math.min(t-last,50)*.00022;last=t;}draw();if(!raf&&(replayAt!==null||energy>.025||drag?.moved||spinning))raf=requestAnimationFrame(tick)}
    cleanup=()=>{dead=true;cancelAnimationFrame(raf);cleanup=null};renderDetail();draw();replay();
  }
  function drawBias(){
    const box=$('researchContent'),items=[{name:'不同基线',category:'长度 · 类型 4',type:3,values:[.98,2.35]},{name:'同一堆叠',category:'长度 · 类型 5',type:4,values:[2.20,2.72]},{name:'饼图角度',category:'角度 · 饼图',type:6,values:[1.36,2.01]}];
    const metrics=['对数绝对偏差','平均对数绝对误差'];let active=1,mode=0,frame=0,current=[0,0,0];const fmt=(v,k)=>(k?'≈':'')+v.toFixed(2);
    box.innerHTML=`<div class="bias-simple-tools"><h3 id="biasMetric">${metrics[0]}</h3><div class="bias-mode" role="group" aria-label="统计量切换"><button data-mode="0" aria-pressed="true">绝对偏差</button><button data-mode="1" aria-pressed="false">平均误差</button></div></div><div class="bias-simple-chart" role="group" aria-label="三种判断类型的统计量比较">${items.map((d,i)=>`<button class="bias-simple-row" data-pick="${i}" aria-pressed="${i===active}"><span class="bias-simple-label"><span class="bias-simple-glyph" aria-hidden="true">${trialGraphic({type:d.type,ratio:60})}</span><span><strong>${d.name}</strong><small>${d.category}</small></span></span><span class="bias-simple-track"><span class="bias-simple-bar"></span></span><b class="bias-simple-value">0.00</b></button>`).join('')}<div class="bias-simple-axis" aria-hidden="true"><span></span><span class="bias-simple-ticks"><span>0</span><span>1</span><span>2</span><span>3</span></span><span></span></div></div><p class="bias-simple-summary" id="biasFocus" aria-live="polite"></p><p class="fine bias-footer">图形为示意。偏差据原文，平均误差为原文图表近似读数；两者统计口径不同，不可相减。</p>`;
    const rows=[...box.querySelectorAll('.bias-simple-row')],heading=$('biasMetric'),focus=$('biasFocus');
    function select(i){active=i;rows.forEach((row,j)=>row.setAttribute('aria-pressed',String(j===active)));const d=items[i],rank=[...items].sort((a,b)=>a.values[mode]-b.values[mode]).indexOf(d);focus.textContent=`${d.name}的${mode?'平均误差':'绝对偏差'}${rank===0?'最低':rank===2?'最高':'居中'}。`;if(!reduced.matches)focus.animate([{opacity:.3},{opacity:1}],{duration:280})}
    function render(next){cancelAnimationFrame(frame);mode=next;heading.textContent=metrics[mode];box.querySelectorAll('button[data-mode]').forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.mode===mode)));select(active);const start=performance.now(),from=[...current],end=items.map(d=>d.values[mode]);rows.forEach((row,i)=>row.setAttribute('aria-label',`${items[i].name}，${metrics[mode]} ${fmt(end[i],mode)}`));const paint=t=>{if(!heading.isConnected)return;const p=reduced.matches?1:Math.min(1,Math.max(0,(t-start)/750)),e=1-Math.pow(1-p,3);rows.forEach((row,i)=>{current[i]=from[i]+(end[i]-from[i])*e;row.querySelector('.bias-simple-bar').style.width=`${current[i]/3*100}%`;row.querySelector('.bias-simple-value').textContent=fmt(current[i],mode)});if(p<1)frame=requestAnimationFrame(paint)};paint(start)}
    rows.forEach((row,i)=>row.onclick=()=>select(i));box.querySelectorAll('button[data-mode]').forEach(b=>b.onclick=()=>render(+b.dataset.mode));render(0);
  }
  renderResearch=function(){cleanup?.();if(researchTab===3)drawTree();else{oldResearch();if(researchTab===2)drawBias()}};if(page===5&&researchTab===3)renderResearch();
  const previousPage=showPage;showPage=function(i){if(i!==5)cleanup?.();previousPage(i)};
})();
