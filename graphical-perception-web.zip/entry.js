/* Scroll-controlled optical zoom into the actual homepage. */
(() => {
  'use strict';
  if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  const screen=document.querySelector('.screen'),home=document.querySelector('#home');
  const viewport=screen?.querySelector(':scope > main');
  if(!screen||!home||!viewport||!screen.clientWidth)return;
  let active=null,quietUntil=0;
  const homeAtTop=()=>!home.hidden&&viewport.scrollTop<=8&&
    (typeof transitioning==='undefined'||!transitioning);
  function onWheel(e){
    if(e.ctrlKey)return;
    const delta=e.deltaY*(e.deltaMode===1?32:e.deltaMode===2?400:1);
    if(!active&&delta<0&&homeAtTop()){
      begin(1);
    }
    if(active){
      e.preventDefault();e.stopImmediatePropagation();
      active.advance(Math.max(-180,Math.min(180,delta))/620);
    }else if(!home.hidden&&delta>0&&performance.now()<quietUntil){
      e.preventDefault();e.stopImmediatePropagation();
      quietUntil=performance.now()+350;
    }
  }
  function onHomeKey(e){
    if(active||!homeAtTop()||!['PageUp','ArrowUp'].includes(e.key)||
      e.target.matches?.('input,button,a,select,textarea'))return;
    e.preventDefault();e.stopImmediatePropagation();
    begin(1);active.advance(-.20);
  }
  window.addEventListener('wheel',onWheel,{capture:true,passive:false});
  window.addEventListener('keydown',onHomeKey,true);
  if(homeAtTop()&&(!startHash||startHash==='home'))begin(0);
  function begin(initial){
  if(active||home.hidden)return;
  const initialOverlay=initial===0?screen.querySelector(':scope > .entry-boot-placeholder'):null;
  const overlay=initialOverlay||document.createElement('div');
  overlay.className='entry-overlay';
  overlay.removeAttribute('aria-hidden');
  overlay.setAttribute('aria-label','网站开场动画，向下滚动或按方向键进入，按 Enter 跳过');
  if(!initialOverlay)overlay.innerHTML=`
    <div class="entry-surface" aria-hidden="true"></div>
    <div class="entry-brand" aria-hidden="true">
      <span>GRAPHICAL</span><span class="entry-brand-gap"><i class="entry-caret"></i></span>
      <span class="entry-word-right">PERCEPTION <span class="entry-year">/ 1984</span></span>
    </div>
    <div class="entry-window" aria-hidden="true"></div>
    <div class="entry-guide" aria-hidden="true"><span class="entry-mouse"></span></div>`;
  const stage=overlay.querySelector('.entry-window');
  const preview=screen.cloneNode(false);
  preview.className='screen entry-preview';
  preview.setAttribute('aria-hidden','true');
  preview.inert=true;
  for(const el of screen.querySelectorAll(':scope > header,:scope > main,:scope > footer')){
    const copy=el.cloneNode(true);
    if(copy.tagName==='MAIN'){
      for(const child of [...copy.children])if(child.id!=='home')child.remove();
    }
    preview.append(copy);
  }
  // Preserve the exact homepage design and isolate duplicated SVG clip paths.
  const ids=new Map();
  preview.querySelectorAll('svg [id]').forEach(el=>{
    const id=el.id;ids.set(id,'entry-'+id);el.id='entry-'+id;
  });
  preview.querySelectorAll('svg *').forEach(el=>{
    for(const a of [...el.attributes]){
      let val=a.value;
      for(const [oldId,newId] of ids){
        val=val.replaceAll('url(#'+oldId+')','url(#'+newId+')');
        if(val==='#'+oldId)val='#'+newId;
      }
      if(val!==a.value)el.setAttribute(a.name,val);
    }
  });
  const bounds=screen.getBoundingClientRect();
  const scale=Math.min(.38,Math.max(.16,230/bounds.width));
  overlay.style.setProperty('--entry-card-width',bounds.width*scale+'px');
  overlay.style.setProperty('--entry-card-height',bounds.height*scale+'px');
  preview.style.width=bounds.width+'px';
  preview.style.height=bounds.height+'px';
  preview.style.transform='translate(-50%,-50%) scale('+scale+')';
  stage.append(preview);
  const locked=[...screen.querySelectorAll(':scope > header,:scope > main,:scope > footer')];
  const previous=locked.map(el=>el.inert);
  const brand=overlay.querySelector('.entry-brand');
  const gap=overlay.querySelector('.entry-brand-gap');
  const caret=overlay.querySelector('.entry-caret');
  const guide=overlay.querySelector('.entry-guide');
  let baseGap=5;
  let done=false,frame=0,position=initial,target=initial,lastTime=0,touchY=null;
  const clamp=(v)=>Math.max(0,Math.min(1,v));
  const smooth=(v)=>{v=clamp(v);return v*v*(3-2*v)};
  function render(p){
    const reveal=smooth(p/.23),zoom=clamp((p-.23)/.77);
    const magnification=scale*Math.pow(1/scale,zoom);
    gap.style.width=(baseGap+bounds.width*magnification*reveal+24*reveal)+'px';
    caret.style.opacity=String(1-smooth(p/.06));
    brand.style.opacity=String(1-smooth((zoom-.02)/.22));
    stage.style.opacity=String(reveal);
    stage.style.clipPath=zoom>0?'none':'inset(calc(50% - '+(bounds.height*scale/2)+'px) calc(50% - '+(bounds.width*scale*reveal/2)+'px))';
    preview.style.transform='translate(-50%,-50%) scale('+magnification+')';
    preview.style.setProperty('--entry-shade',String(.21*smooth((zoom-.76)/.24)));
    preview.style.setProperty('--entry-edge',String(.30*(1-smooth((zoom-.66)/.34))));
    guide.style.opacity=String(1-smooth((p-.68)/.26));
    overlay.dataset.progress=p.toFixed(3);
  }
  function tick(now){
    frame=0;
    if(done)return;
    const dt=lastTime?Math.min(50,now-lastTime):16;
    lastTime=now;
    position+=(target-position)*(1-Math.exp(-dt/76));
    if(Math.abs(target-position)<.0015)position=target;
    render(position);
    if(position>=.998&&target===1){finish(true);return}
    if(position!==target)frame=requestAnimationFrame(tick);else lastTime=0;
  }
  function advance(delta){
    target=clamp(target+delta);
    if(!frame){lastTime=0;frame=requestAnimationFrame(tick)}
  }
  function touchStart(e){touchY=e.touches[0]?.clientY??null}
  function touchMove(e){
    if(touchY===null||!e.touches.length)return;
    const y=e.touches[0].clientY;
    e.preventDefault();e.stopPropagation();
    advance((touchY-y)/Math.max(300,bounds.height*.7));
    touchY=y;
  }
  function touchEnd(){touchY=null}
  function finish(fromScroll=false){
    if(done)return;done=true;
    if(frame)cancelAnimationFrame(frame);
    active=null;
    quietUntil=fromScroll?performance.now()+350:0;
    home.style.animation='none';
    const restore=new MutationObserver(()=>{
      if(home.hidden){home.style.removeProperty('animation');restore.disconnect()}
    });
    restore.observe(home,{attributes:true,attributeFilter:['hidden']});
    screen.classList.remove('is-entering');
    locked.forEach((el,i)=>{el.inert=previous[i]});
    overlay.remove();
    document.removeEventListener('keydown',key,true);
    window.removeEventListener('resize',exit);
    window.removeEventListener('pagehide',exit);
  }
  function exit(){finish(false)}
  function key(e){
    if(e.key==='Escape'||e.key==='Enter'){
      e.preventDefault();e.stopImmediatePropagation();finish();
    }else if(['PageDown','PageUp','ArrowDown','ArrowUp',' '].includes(e.key)){
      e.preventDefault();e.stopImmediatePropagation();
      advance(['PageUp','ArrowUp'].includes(e.key)?-.20:.24);
    }
  }
  screen.classList.add('is-entering');
  locked.forEach(el=>{el.inert=true});
  screen.append(overlay);
  baseGap=parseFloat(getComputedStyle(brand).fontSize)*.90;
  document.addEventListener('keydown',key,true);
  overlay.addEventListener('touchstart',touchStart,{passive:true});
  overlay.addEventListener('touchmove',touchMove,{passive:false});
  overlay.addEventListener('touchend',touchEnd);
  overlay.addEventListener('touchcancel',touchEnd);
  window.addEventListener('resize',exit,{once:true});
  window.addEventListener('pagehide',exit,{once:true});
  active={advance};
  render(initial);
  document.documentElement.classList.remove('entry-preparing');
  }
})();
